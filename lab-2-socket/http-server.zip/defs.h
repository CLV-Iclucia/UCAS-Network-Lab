// add protection
#ifndef DEFS_H
#define DEFS_H

#define HTTP_PORT 80
#define HTTPS_PORT 443
#define BUFFER_SIZE 1024
#define HTTP_VERSION_MAJOR 1
#define HTTP_VERSION_MINOR 1

#endif