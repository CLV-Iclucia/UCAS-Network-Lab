#ifndef MY_LOG_H
#define MY_LOG_H

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

// after I finish this I found that there is already a log in include/
// but that's fine, since mine is more powerful and I can use it in other C projects
enum log_color {
  LOG_BLACK = 30,
  LOG_RED = 31,
  LOG_GREEN = 32,
  LOG_YELLOW = 33,
  LOG_BLUE = 34,
  LOG_MAGENTA = 35,
  LOG_CYAN = 36,
  LOG_WHITE = 37,
  LOG_RESET = 0
};

enum log_level {
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR,
    LOG_FATAL,
};

void start_logging(const char* file_name);
void set_log_level(enum log_level level);
void log_msg(log_level level, const char* format, ...);
void stop_logging();
#endif