#include "my-log.h"
#include <pthread.h>

static FILE* fp = NULL;
// considering that multiple threads might need to use log
// I should make it thread-safe
static pthread_spinlock_t lock;
static enum log_level global_log_level = LOG_DEBUG;

static enum log_color get_color_for_log_level(enum log_level level) {
  switch (level) {
    case LOG_DEBUG:
      return LOG_BLUE;
    case LOG_INFO:
      return LOG_GREEN;
    case LOG_WARN:
      return LOG_YELLOW;
    case LOG_ERROR:
      return LOG_RED;
    case LOG_FATAL:
      return LOG_MAGENTA;
    default:
      return LOG_RESET; // 默认为重置颜色
  }
}

static const char *log_level_to_string(enum log_level level) {
  switch (level) {
    case LOG_DEBUG:
      return "DEBUG";
    case LOG_INFO:
      return "INFO";
    case LOG_WARN:
      return "WARN";
    case LOG_ERROR:
      return "ERROR";
    case LOG_FATAL:
      return "FATAL";
    default:
      return "UNKNOWN";
  }
}

void start_logging(const char* file_name) {
  pthread_spin_init(&lock);
  fp = fopen(file_name);
  if (fp == NULL)
    perror("cannot open log");
}

void set_log_level(enum log_level level) {
  pthread_spin_lock(&log_level_lock);
  global_log_level = level;
  pthread_spin_unlock(&log_level_lock);
}

// print log based on log levels, thread-safe
void log_msg(enum log_level level, const char* format, ...) {
  pthread_spin_lock(&lock);
  if (level >= global_log_level) {
    enum log_color color = get_color_for_log_level(level);
    pthread_t tid = pthread_self();
    printf("\x1B[%dm[%s] [Thread: %lu] %s\x1B[0m", color, log_level_to_string(level), tid, message);
  }
  pthread_spin_unlock(&lock);
}

void stop_logging() {
  pthread_spin_lock(&lock);
  fclose(fp);
  fp = NULL;
  pthread_spin_unlock(&lock);
}